import argparse
import numpy as np
from PIL import Image
import tensorflow as tf

CLASS_NAMES = ['airplane','automobile','bird','cat','deer','dog','frog','horse','ship','truck']

def load_and_prep_image(image_path, target_size=(32,32)):
    img = Image.open(image_path).convert('RGB').resize(target_size)
    arr = np.array(img).astype('float32')/255.0
    return np.expand_dims(arr, axis=0)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--image', required=True, help='Path to image file')
    args = parser.parse_args()

    model = tf.keras.models.load_model('models/cnn_cifar10.keras')
    x = load_and_prep_image(args.image)
    probs = model.predict(x)[0]
    idx = int(np.argmax(probs))
    print(f'Predicted: {CLASS_NAMES[idx]} (confidence {probs[idx]:.2f})')

if __name__ == '__main__':
    main()
