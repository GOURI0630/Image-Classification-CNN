# 🤖 Image Classification using CNN

A simple Convolutional Neural Network (CNN) project that classifies images from the CIFAR-10 dataset (10 classes: airplane, automobile, bird, cat, deer, dog, frog, horse, ship, truck).

## 📌 Features
- Loads CIFAR-10 dataset using TensorFlow/Keras
- Builds a small CNN model (Conv2D + MaxPool + Dense)
- Trains and evaluates the model
- Saves the trained model to `models/cnn_cifar10.keras`

## 🚀 How to Run
1. Clone this repository:
   ```bash
   git clone https://github.com/YourUsername/Image-Classification-CNN.git
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Train the model:
   ```bash
   python cnn_image_classification.py
   ```
4. (Optional) Predict on a single image:
   ```bash
   python predict_single.py --image path/to/your_image.png
   ```

## 🛠 Requirements
See `requirements.txt` for dependencies.

## 📦 Output
- Trained model: `models/cnn_cifar10.keras`
- Training logs printed to console

⭐ **Made with ❤️ by [Gouri Sunil Kumar](https://github.com/GOURI0630)**
